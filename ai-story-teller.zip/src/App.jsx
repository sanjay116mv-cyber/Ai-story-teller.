import React, { useState } from "react";

export default function App() {
  const [prompt, setPrompt] = useState("");
  const [story, setStory] = useState("");
  const [loading, setLoading] = useState(false);

  const getStory = async () => {
    setLoading(true);
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": "Bearer YOUR_OPENAI_API_KEY",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4",
        messages: [{ role: "user", content: `Tell a story about ${prompt}` }],
      }),
    });

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;
    setStory(content || "No story returned.");
    setLoading(false);
  };

  return (
    <div style={{ padding: "2rem", fontFamily: "sans-serif", background: "#111", color: "#eee", minHeight: "100vh" }}>
      <h1>AI Story Teller</h1>
      <input
        type="text"
        placeholder="Enter story topic..."
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        style={{ padding: "0.5rem", width: "300px" }}
      />
      <button onClick={getStory} style={{ marginLeft: "1rem" }}>Tell Story</button>
      {loading ? <p>Loading...</p> : <pre>{story}</pre>}
    </div>
  );
}